#! ./micropython

import time
import struct
import uctypes
import uarray
import gc
import micropython
import sys

from display_driver_utils import driver
drv = driver( width=__UI_PROJECT_HOR_RES__, height=__UI_PROJECT_VER_RES__ )

import ui
print( "Free memory: " + str(gc.mem_free()) )

while True: time.sleep(1)

