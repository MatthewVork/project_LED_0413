#!/bin/bash

#sudo  apt-get  install  build-essential libreadline-dev libffi-dev git pkg-config libsdl2-2.0-0 libsdl2-dev python3.8 parallel

cd  lv_micropython

cp  ../corrections/lv_conf.h  lib/lv_bindings/  #adds all fonts, etc.
cp  ../corrections/lv_textarea.c  lib/lv_bindings/lvgl/src/widgets/  #lv_textarea_set_align() renamed to lv_textarea_align_set(),
cp  ../corrections/lv_textarea.h  lib/lv_bindings/lvgl/src/widgets/  #so it doesn't overhadow the lv_obj_set_align() for textarea in MicroPython binding generator (It's an obsolete function anyway)
cp  ../corrections/lv_roller.c  lib/lv_bindings/lvgl/src/widgets/  #a cast from uint to int was needed so MacOS version could be built without using -Wno-format-truncation which was unsupported by MacOS
cp  ../corrections/lv_fs_stdio.c  lib/lv_bindings/lvgl/src/extra/libs/fsdrv  #a +1 was added to length-argument of snprintf() because -Werror=format-trunciation would cause a build problem
cp  ../corrections/py.mk  py/  #LVGL internal lodepng should be used, this removes build-time conflict with MicroPython's own lodepng
cp  ../corrections/manifest.py  ports/windows/variants/manifest.py  #adds python modules to windows-port (display_driver_utils, etc.)
cp  ../corrections/manifest.py  ports/unix/variants/  #comments out image-tools which caused building problem on MacOS

make  -C mpy-cross  -j  # CFLAGS_EXTRA="-DMICROPY_MODULE_BUILTIN_INIT=1 -D MICROPY_ENABLE_SCHEDULER=1"


make  -C ports/unix  -j  CFLAGS_EXTRA=-Wno-format-truncation  #avoid lv_fs_stdio.c snprintf error

#cp  -r  shared/timeutils/  lib/  #compensate for the obsolete path in ports/windows Makefile - but also doable in the make command in next row by overriding variables:
make  -C ports/windows  -j  CROSS_COMPILE=i686-w64-mingw32-  LIB_SRC_C="shared/timeutils/timeutils.c"  LIB="-lws2_32"  CFLAGS_EXTRA=-DBYTES_PER_WORD="\(sizeof\(mp_uint_t\)\)"  #remove SDL, compensate for lack of BYTES_PER_WORD in ports/windows

cp  ports/unix/micropython  ../
cp  ports/windows/micropython.exe ../

