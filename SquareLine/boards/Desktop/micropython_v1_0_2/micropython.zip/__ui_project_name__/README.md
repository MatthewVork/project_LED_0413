# Micropython + LVGL for SquareLine Studio

Use `run.sh` or `run.bat` (or `main.py` directly) to run the UI exported from SquareLine Studio with the pre-built Linux/Windows MicroPython on PC.

In case you want to recompile micropython, you can get it from GitHub via `clone.sh` or/then you can build it with `build.sh` on Unix (Linux/MacOS).
The scripts take care of downloading the tested and working snapshots from the git repository, and adding the necessary patches in `corrections` folder to make them buildable.
The `micropython` (and if gcc-mingw is installed, `micropythen.exe`) executables will be generated in this very folder.

For other supported platforms you have to use their respective folders in `lv_micropython/ports` folder to build the micropython executable.
(On MacOS you can use the same method to build it as on Linux (`build.sh`), using the same Makefile in the `ports/unix` folder.)
