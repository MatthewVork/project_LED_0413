#/bin/sh
cd  lv_micropython
make  -C mpy-cross  clean
make  -C ports/unix  clean
make  -C ports/windows  clean
