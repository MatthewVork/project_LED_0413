#!/bin/bash

git  clone  --branch "release/v8"  --single-branch  -c advice.detachedHead=false  https://github.com/lvgl/lv_micropython  #supports submodules, needs the checkout at certain state (mostly an LVGL submodule version update)
#alternative: git  clone  --branch "v1.19.1"  --single-branch  --depth 1  -c advice.detachedHead=false  https://github.com/lvgl/lv_micropython  #9b486340da22931cde82872f79e1c34db959548b: had no submodule support (because it's a release-tag)

cd  lv_micropython

git  checkout cae7a7c73d07497d63d627659e5c34601337673c #8496f74cfa234985a2cf8cff24ac1fae46446d71 #9b486340da22931cde82872f79e1c34db959548b  #1.19.1 is already at this

git  submodule  update  --init  --recursive  lib/lv_bindings  #submodules: lv_bindings, lvgl, lodepng?, pycparser

make  -C mpy-cross  submodules
make  -C ports/unix  submodules  #submodules: axtls, berkeley-db-1.xx, libffi
make  -C ports/windows  submodules

rm  -rf  lib/lv_bindings/lvgl
git  clone  --branch "v8.3.11"  --single-branch  --depth 1  -c advice.detachedHead=false  https://github.com/lvgl/lvgl  lib/lv_bindings/lvgl
rm  -rf  lib/lv_bindings/lvgl/demos/  lib/lv_bindings/lvgl/docs/  lib/lv_bindings/lvgl/examples/  lib/lv_bindings/lvgl/tests/  lib/lv_bindings/lvgl/scripts/

find . -name ".git*" -exec rm -rf {} \;  #rm -rf .git*  #remove 450MB git stuff unnecessary for build



