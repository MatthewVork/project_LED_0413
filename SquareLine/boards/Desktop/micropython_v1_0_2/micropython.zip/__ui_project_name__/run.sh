#!/bin/sh
./micropython  -X heapsize=1024M  main.py
