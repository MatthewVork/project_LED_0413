#!/bin/bash

#sudo  apt-get  install  build-essential libreadline-dev libffi-dev git pkg-config libsdl2-2.0-0 libsdl2-dev python3.8 parallel

cd  lv_micropython

cp  ports/unix/variants/manifest.py  ports/windows/variants  #adds python modules to windows-port (display_driver_utils, etc.)
cp  -r  ../corrections/*  ./    #lv_conf.h enables all fonts, etc.

make  -C mpy-cross  -j


make  -C ports/unix  -j

sed -i 's/^#include "lib\/lv_bindings\/lvgl\/src\/misc\/lv_gc.h"/\/\/&/' ports/windows/mpconfigport.h  #remove include for lv_gc.h which is missing by now from LVGL
make  -C ports/windows  -j  CROSS_COMPILE=i686-w64-mingw32-  LIB_SRC_C="shared/timeutils/timeutils.c"  LIB="-lws2_32"  CFLAGS_EXTRA=-DBYTES_PER_WORD="\(sizeof\(mp_uint_t\)\)"  #remove SDL, compensate for lack of BYTES_PER_WORD in ports/windows

cp  ports/unix/build-standard/micropython  ../
cp  ports/windows/build-standard/micropython.exe  ../
