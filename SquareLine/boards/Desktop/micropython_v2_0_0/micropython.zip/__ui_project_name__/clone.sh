#!/bin/sh

git  clone https://github.com/lvgl/lv_micropython.git
#alternative: git  clone  --branch "v1.20.0"  --single-branch  --depth 1  -c advice.detachedHead=false  https://github.com/lvgl/lv_micropython  #294baf52b346e400e2255c6c1e82af5b978b18f7: had no submodule support (because it's a release-tag)

cd  lv_micropython

git  checkout 78abbb1488dd1d6665947356b0db6a4ec26606ae  #snapshot with LVGL-9.1.0 support just added

git submodule update --init --recursive lib/lv_bindings  #submodules: lv_bindings, lvgl, lodepng?, pycparser, ...

make  -C mpy-cross  submodules
make  -C ports/unix  submodules  #submodules: axtls, berkeley-db-1.xx, libffi, ...
make  -C ports/windows  submodules

git  checkout d01975bd641bf4c5397baddc80d6306e8d6c0bc2  /lib/lv_bindings  #commit above already specifies this snapshot

cd lib/lv_bindings/lvgl
git checkout v9.1.0      #better being at a pure 9.1.0
cd ../../../

#rm  -rf  lib/lv_bindings/lvgl
#git  clone  --branch "v9.1.1"  --single-branch  --depth 1  -c advice.detachedHead=false  https://github.com/lvgl/lvgl  lib/lv_bindings/lvgl  #if LVGL is to be changed
rm  -rf  lib/lv_bindings/lvgl/demos/  lib/lv_bindings/lvgl/docs/  lib/lv_bindings/lvgl/examples/  lib/lv_bindings/lvgl/tests/  lib/lv_bindings/lvgl/scripts/  lib/lv_bindings/lvgl/.devcontainer/

find . -name ".git*" -exec rm -rf {} \;  #rm -rf .git*  #remove ~500MB git stuff unnecessary for build

cd ../

