/*
 * ESPRESSIF MIT License
 *
 * Copyright (c) 2021 <ESPRESSIF SYSTEMS (SHANGHAI) CO., LTD>
 *
 * Permission is hereby granted for use on all ESPRESSIF SYSTEMS products, in which case,
 * it is free of charge, to any person obtaining a copy of this software and associated
 * documentation files (the "Software"), to deal in the Software without restriction, including
 * without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the Software is furnished
 * to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all copies or
 * substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS
 * FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
 * COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER
 * IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
 * CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 */

#ifndef _ES7210_H
#define _ES7210_H

#include "audio_hal.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef enum {
    ES7210_AD1_AD0_00 = 0x40,
    ES7210_AD1_AD0_01 = 0x41,
    ES7210_AD1_AD0_10 = 0x42,
    ES7210_AD1_AD0_11 = 0x43,
} es7210_address_t;

typedef enum {
    ES7210_INPUT_MIC1 = 0x01,
    ES7210_INPUT_MIC2 = 0x02,
    ES7210_INPUT_MIC3 = 0x04,
    ES7210_INPUT_MIC4 = 0x08
} es7210_input_mics_t;

typedef enum gain_value{
	GAIN_0DB = 0,
	GAIN_3DB,
	GAIN_6DB,
	GAIN_9DB,
	GAIN_12DB,
	GAIN_15DB,
	GAIN_18DB,
	GAIN_21DB,
	GAIN_24DB,
	GAIN_27DB,
	GAIN_30DB,
	GAIN_33DB,
	GAIN_34_5DB,
	GAIN_36DB,
	GAIN_37_5DB,
} es7210_gain_value_t;

/*
 * @brief Initialize ES7210 ADC chip
 *
 * @param[in] codec_cfg:  configuration of ES7210
 *
 * @return
 *      - ESP_OK
 *      - ESP_FAIL
 */
esp_err_t es7210_adc_init(uint8_t i2c_addr, audio_hal_codec_config_t *codec_cfg);

/**
 * @brief Deinitialize ES7210 ADC chip
 *
 * @return
 *     - ESP_OK
 *     - ESP_FAIL
 */
esp_err_t es7210_adc_deinit();

/**
 * @brief Configure ES7210 ADC mode and I2S interface
 *
 * @param[in] mode:  codec mode
 * @param[in] iface:  I2S config
 *
 * @return
 *     - ESP_FAIL Parameter error
 *     - ESP_OK   Success
 */
esp_err_t es7210_adc_config_i2s(audio_hal_codec_mode_t mode, audio_hal_codec_i2s_iface_t *iface);

/**
 * @brief Control ES7210 ADC chip
 *
 * @param[in] mode:  codec mode
 * @param[in] ctrl_state:  start or stop progress
 *
 * @return
 *     - ESP_FAIL Parameter error
 *     - ESP_OK   Success
 */
esp_err_t es7210_adc_ctrl_state(audio_hal_codec_mode_t mode, audio_hal_ctrl_t ctrl_state);

/**
 * @brief  Set gain of given mask
 *
 * @param[in] mic_mask Mask of MIC channel
 * 
 * @param[in] gain:  gain 
 * 
 *       gain        :   value
 *       GAIN_0DB    :   1
 *       GAIN_3DB    :   2
 *       GAIN_6DB    :   3
 *           ·
 *           ·
 *           ·
 *       GAIN_30DB   :   10
 *       GAIN_33DB   :   11
 *       GAIN_34_5DB :   12
 *       GAIN_36DB   :   13
 *       GAIN_37_5DB :   14
 *
 * @return
 *     - ESP_OK
 *     - ESP_FAIL
 */
esp_err_t es7210_adc_set_gain(es7210_input_mics_t mic_mask, es7210_gain_value_t gain);

/**
 * @brief  Set gain (Note: the enabled microphone sets the same gain)
 *
 * @param[in] gain:  gain 
 * 
 *       gain        :   value
 *       GAIN_0DB    :   1
 *       GAIN_3DB    :   2
 *       GAIN_6DB    :   3
 *           ·
 *           ·
 *           ·
 *       GAIN_30DB   :   10
 *       GAIN_33DB   :   11
 *       GAIN_34_5DB :   12
 *       GAIN_36DB   :   13
 *       GAIN_37_5DB :   14
 *
 * @return
 *     - ESP_OK
 *     - ESP_FAIL
 */
esp_err_t es7210_adc_set_gain_all(es7210_gain_value_t gain);

/**
 * @brief Get MIC gain
 * 
 * @param mic_mask Selected MIC
 * @param gain Pointer to `es7210_gain_value_t`
 * @return
 *     - ESP_OK
 *     - ESP_FAIL
 */
esp_err_t es7210_adc_get_gain(es7210_input_mics_t mic_mask, es7210_gain_value_t *gain);

/**
 * @brief Set volume
 *
 * @param[in] volume:  volume
 *
 * @return
 *     - ESP_OK
 */
esp_err_t es7210_adc_set_volume(int volume);

/**
 * @brief Set ES7210 ADC mute status
 *
 * @return
 *     - ESP_FAIL
 *     - ESP_OK
 */
esp_err_t es7210_set_mute(bool enable);

/**
 * @brief Select ES7210 mic
 *
 * @param[in] mic:  mics
 * 
 * @return
 *     - ESP_FAIL
 *     - ESP_OK
 */
esp_err_t es7210_mic_select(es7210_input_mics_t mic);

/**
 * @brief Read regs of ES7210
 *
 * @param[in] reg_addr:  reg_addr
 * 
 * @return
 *     - ESP_FAIL
 *     - ESP_OK
 */
int es7210_read_reg(uint8_t reg_addr);

/**
 * @brief Read all regs of ES7210
 */
void es7210_read_all(void);

#ifdef __cplusplus
}
#endif

#endif /* _ES7210_H_ */
